(() => {
  'use strict';
  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => [...c.querySelectorAll(s)];
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const fine = matchMedia('(hover:hover) and (pointer:fine)').matches;
  const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));

  /* year */
  $('#yr').textContent = new Date().getFullYear();

  /* hero intro */
  requestAnimationFrame(() => requestAnimationFrame(() => document.documentElement.classList.add('ready')));

  /* ---------- marquee: clone content once so -50% loops seamlessly ---------- */
  $$('.mq').forEach(m => {
    m.style.setProperty('--sp', (m.dataset.speed || 30) + 's');
    [...m.children].forEach(c => { const k = c.cloneNode(true); k.setAttribute('aria-hidden', 'true'); m.appendChild(k); });
  });

  /* ---------- reveal on scroll ---------- */
  const io = new IntersectionObserver(es => es.forEach(e => {
    if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
  }), { threshold: .12, rootMargin: '0px 0px -6% 0px' });
  $$('.rv').forEach(el => io.observe(el));

  /* ---------- counters ---------- */
  const cio = new IntersectionObserver(es => es.forEach(e => {
    if (!e.isIntersecting) return;
    cio.unobserve(e.target);
    const to = +e.target.dataset.count; if (reduce) return;
    const t0 = performance.now(), d = 1400;
    const tick = t => { const p = clamp((t - t0) / d); e.target.textContent = Math.round(to * (1 - Math.pow(1 - p, 3))); if (p < 1) requestAnimationFrame(tick); };
    e.target.textContent = 0; requestAnimationFrame(tick);
  }), { threshold: .6 });
  $$('[data-count]').forEach(el => cio.observe(el));

  /* ---------- nav: stuck state, scroll progress, scroll-spy, mobile menu, fab ---------- */
  const nav = $('#nav'), prog = $('#progress'), fab = $('#fab');
  const links = $$('#links a[href^="#"]:not(.btn)');
  const secs = links.map(a => $(a.getAttribute('href'))).filter(Boolean);
  const burger = $('#burger'), menu = $('#links');
  const setMenu = o => { menu.classList.toggle('open', o); burger.setAttribute('aria-expanded', o); burger.setAttribute('aria-label', o ? 'Close menu' : 'Open menu'); };
  burger.addEventListener('click', () => setMenu(!menu.classList.contains('open')));
  menu.addEventListener('click', e => { if (e.target.closest('a')) setMenu(false); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') setMenu(false); });

  /* ---------- tagline word-by-word scroll reveal ---------- */
  const tl = $('#tagline'), tlText = $('#tlText'), ghost = $('#ghost');
  const wrapWords = node => {
    [...node.childNodes].forEach(n => {
      if (n.nodeType === 3) {
        const f = document.createDocumentFragment();
        n.textContent.split(/(\s+)/).forEach(p => {
          if (!p) return;
          if (/^\s+$/.test(p)) f.appendChild(document.createTextNode(' '));
          else { const s = document.createElement('span'); s.className = 'tw'; s.textContent = p; s.setAttribute('aria-hidden', 'true'); f.appendChild(s); }
        });
        node.replaceChild(f, n);
      } else if (n.nodeType === 1) wrapWords(n);
    });
  };
  wrapWords(tlText);
  const words = $$('.tw', tlText);

  /* ---------- progress line in process ---------- */
  const steps = $('#steps'), fill = $('#lineFill');

  /* single rAF-throttled scroll handler */
  let ticking = false;
  const onScroll = () => {
    const y = scrollY, h = document.documentElement.scrollHeight - innerHeight;
    prog.style.transform = `scaleX(${h > 0 ? y / h : 0})`;
    nav.classList.toggle('stuck', y > 8);
    fab.classList.toggle('show', y > innerHeight * .8 && !(contactTop() < innerHeight * .6));

    /* spy */
    let cur = secs[0];
    secs.forEach(s => { if (s.getBoundingClientRect().top <= innerHeight * .35) cur = s; });
    links.forEach(a => a.classList.toggle('active', $(a.getAttribute('href')) === cur));

    /* tagline */
    const r = tl.getBoundingClientRect();
    const p = clamp(-r.top / (r.height - innerHeight));
    if (!reduce) {
      const n = Math.round(p * 1.15 * words.length);
      words.forEach((w, i) => w.classList.toggle('on', i < n));
      ghost.style.transform = `translateX(${-p * 40}%)`;
    }

    /* process line */
    const sr = steps.getBoundingClientRect();
    fill.style.transform = `scaleX(${clamp((innerHeight * .7 - sr.top) / (sr.height * .9))})`;

    /* about parallax */
    if (!reduce) $$('[data-par]').forEach(el => {
      const b = el.getBoundingClientRect();
      el.style.transform = `translateY(${(b.top + b.height / 2 - innerHeight / 2) * +el.dataset.par}px)`;
    });
    ticking = false;
  };
  const contactEl = $('#contact');
  const contactTop = () => contactEl.getBoundingClientRect().top;
  addEventListener('scroll', () => { if (!ticking) { ticking = true; requestAnimationFrame(onScroll); } }, { passive: true });
  addEventListener('resize', onScroll);
  onScroll();

  /* ---------- hero: interactive particle network ---------- */
  (() => {
    const cv = $('#net'), ctx = cv.getContext('2d'), hero = $('#home');
    let W, H, dpr, pts = [], run = true, vis = true;
    const mouse = { x: -999, y: -999 };
    const build = () => {
      dpr = Math.min(devicePixelRatio || 1, 2);
      W = hero.clientWidth; H = hero.clientHeight;
      cv.width = W * dpr; cv.height = H * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const n = Math.min(110, Math.round(W * H / 15000));
      pts = Array.from({ length: n }, () => ({
        x: Math.random() * W, y: Math.random() * H,
        vx: (Math.random() - .5) * .35, vy: (Math.random() - .5) * .35,
        r: Math.random() * 1.8 + .8, y2: Math.random() < .12
      }));
    };
    const D = 135;
    const frame = () => {
      if (!run) return;
      ctx.clearRect(0, 0, W, H);
      for (let i = 0; i < pts.length; i++) {
        const a = pts[i];
        a.x += a.vx; a.y += a.vy;
        if (a.x < 0 || a.x > W) a.vx *= -1;
        if (a.y < 0 || a.y > H) a.vy *= -1;
        const dx = a.x - mouse.x, dy = a.y - mouse.y, dm = dx * dx + dy * dy;
        if (dm < 140 * 140 && dm > 1) { const f = (1 - Math.sqrt(dm) / 140) * .9; a.x += dx / Math.sqrt(dm) * f; a.y += dy / Math.sqrt(dm) * f; }
        for (let j = i + 1; j < pts.length; j++) {
          const b = pts[j], x = a.x - b.x, y = a.y - b.y, d = x * x + y * y;
          if (d < D * D) {
            ctx.strokeStyle = `rgba(15,122,103,${(1 - Math.sqrt(d) / D) * .28})`;
            ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
          }
        }
        /* link to cursor */
        if (dm < 190 * 190) {
          ctx.strokeStyle = `rgba(240,180,0,${(1 - Math.sqrt(dm) / 190) * .65})`;
          ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(mouse.x, mouse.y); ctx.stroke();
        }
        ctx.fillStyle = a.y2 ? '#f0b400' : 'rgba(15,122,103,.7)';
        ctx.beginPath(); ctx.arc(a.x, a.y, a.r, 0, 6.283); ctx.fill();
      }
      requestAnimationFrame(frame);
    };
    const start = () => { if (!run && vis && !document.hidden && !reduce) { run = true; requestAnimationFrame(frame); } };
    const stop = () => { run = false; };
    build();
    if (reduce) { run = true; frame(); run = false; } else { requestAnimationFrame(frame); }
    hero.addEventListener('pointermove', e => { const r = hero.getBoundingClientRect(); mouse.x = e.clientX - r.left; mouse.y = e.clientY - r.top; });
    hero.addEventListener('pointerleave', () => { mouse.x = mouse.y = -999; });
    let rt; addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(build, 200); });
    new IntersectionObserver(([e]) => { vis = e.isIntersecting; vis ? start() : stop(); }).observe(hero);
    document.addEventListener('visibilitychange', () => document.hidden ? stop() : start());
  })();

  /* ---------- hero image 3D tilt ---------- */
  (() => {
    const t = $('#tilt'); if (!t || !fine || reduce) return;
    const box = t.parentElement;
    box.addEventListener('pointermove', e => {
      const r = box.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5;
      t.style.transform = `rotateY(${x * 14}deg) rotateX(${-y * 14}deg)`;
    });
    box.addEventListener('pointerleave', () => { t.style.transform = ''; });
  })();

  /* ---------- spotlight on cards ---------- */
  $$('.spot').forEach(c => c.addEventListener('pointermove', e => {
    const r = c.getBoundingClientRect();
    c.style.setProperty('--mx', (e.clientX - r.left) + 'px'); c.style.setProperty('--my', (e.clientY - r.top) + 'px');
  }));

  /* ---------- magnetic buttons ---------- */
  if (fine && !reduce) $$('.magnetic').forEach(b => {
    b.addEventListener('pointermove', e => {
      const r = b.getBoundingClientRect();
      b.style.transform = `translate(${(e.clientX - r.left - r.width / 2) * .22}px,${(e.clientY - r.top - r.height / 2) * .3}px)`;
    });
    b.addEventListener('pointerleave', () => { b.style.transform = ''; });
  });

  /* ---------- services accordion ---------- */
  $$('.svc').forEach(card => {
    const btn = $('.tog', card), label = $('span', btn);
    const toggle = () => {
      const o = !card.classList.contains('open');
      card.classList.toggle('open', o);
      btn.setAttribute('aria-expanded', o);
      label.textContent = o ? 'Hide details' : 'View details';
    };
    btn.addEventListener('click', e => { e.stopPropagation(); toggle(); });
    card.addEventListener('click', e => { if (!e.target.closest('a,button')) toggle(); });
  });

  /* ---------- portfolio: generated artwork ---------- */
  const art = (cat, [c1, c2], id) => {
    const dark = c1 === '#0a4d42' || c2 === '#0b2b26';
    const fg = dark ? '#fffdeb' : '#0b2b26', soft = dark ? 'rgba(255,253,235,.16)' : 'rgba(11,43,38,.13)';
    let s = `<svg viewBox="0 0 400 300" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><defs><linearGradient id="g${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${c1}"/><stop offset="1" stop-color="${c2}"/></linearGradient></defs><rect width="400" height="300" fill="url(#g${id})"/><circle cx="350" cy="30" r="90" fill="${soft}"/><circle cx="30" cy="280" r="70" fill="${soft}"/>`;
    if (cat === 'APP') {
      s += `<rect x="140" y="26" width="120" height="250" rx="20" fill="#fff"/><rect x="150" y="40" width="100" height="62" rx="10" fill="${c1}" opacity=".85"/><rect x="150" y="112" width="60" height="8" rx="4" fill="${soft}"/><rect x="150" y="128" width="100" height="40" rx="8" fill="${soft}"/><rect x="150" y="176" width="100" height="40" rx="8" fill="${soft}"/><circle cx="200" cy="246" r="12" fill="${c2}"/><rect x="70" y="80" width="56" height="86" rx="12" fill="#fff" opacity=".55"/><rect x="274" y="130" width="56" height="86" rx="12" fill="#fff" opacity=".55"/>`;
    } else if (cat === 'BRANDING') {
      s += `<circle cx="200" cy="150" r="78" fill="#fff"/><path d="M158 192V108l42 50 42-50v84" fill="none" stroke="${c2}" stroke-width="16" stroke-linecap="round" stroke-linejoin="round"/><rect x="104" y="250" width="192" height="8" rx="4" fill="${fg}" opacity=".45"/><circle cx="64" cy="64" r="8" fill="${fg}" opacity=".6"/><circle cx="340" cy="236" r="12" fill="${fg}" opacity=".4"/>`;
    } else if (cat === 'WEB') {
      s += `<rect x="46" y="36" width="308" height="228" rx="14" fill="#fff"/><rect x="46" y="36" width="308" height="26" rx="14" fill="${soft}"/><circle cx="64" cy="49" r="4" fill="${c2}"/><circle cx="78" cy="49" r="4" fill="${c1}"/><rect x="62" y="76" width="150" height="14" rx="7" fill="${c2}"/><rect x="62" y="98" width="110" height="8" rx="4" fill="${soft}"/><rect x="62" y="116" width="62" height="20" rx="10" fill="${c1}"/><rect x="236" y="76" width="102" height="72" rx="10" fill="${c1}" opacity=".8"/><rect x="62" y="160" width="84" height="84" rx="10" fill="${soft}"/><rect x="158" y="160" width="84" height="84" rx="10" fill="${soft}"/><rect x="254" y="160" width="84" height="84" rx="10" fill="${soft}"/>`;
    } else {
      s += `<rect x="44" y="40" width="312" height="220" rx="16" fill="#fff"/><rect x="44" y="40" width="64" height="220" rx="16" fill="${c2}" opacity=".9"/><rect x="124" y="58" width="96" height="10" rx="5" fill="${soft}"/><rect x="124" y="82" width="70" height="46" rx="10" fill="${soft}"/><rect x="204" y="82" width="70" height="46" rx="10" fill="${soft}"/><rect x="284" y="82" width="56" height="46" rx="10" fill="${c1}"/><path d="M124 220c24-10 36-60 60-52s32 40 56 22 40-62 100-50" fill="none" stroke="${c2}" stroke-width="5" stroke-linecap="round"/><rect x="124" y="148" width="216" height="6" rx="3" fill="${soft}"/>`;
    }
    return s + '</svg>';
  };
  $$('.wk').forEach((a, i) => { $('.thumb', a).innerHTML = art(a.dataset.cat, a.dataset.c.split(','), i); });

  /* ---------- portfolio: FLIP filter ---------- */
  (() => {
    const grid = $('#work'), items = $$('.wk', grid), bar = $('#filters');
    bar.addEventListener('click', e => {
      const b = e.target.closest('button'); if (!b) return;
      $$('button', bar).forEach(x => { const on = x === b; x.classList.toggle('on', on); x.setAttribute('aria-selected', on); });
      const f = b.dataset.f;
      const first = new Map(items.filter(i => !i.hidden).map(i => [i, i.getBoundingClientRect()]));
      items.forEach(i => { i.hidden = !(f === 'all' || i.dataset.cat === f); });
      if (reduce) return;
      items.forEach(i => {
        if (i.hidden) return;
        const r = i.getBoundingClientRect(), p = first.get(i);
        i.animate(p
          ? [{ transform: `translate(${p.left - r.left}px,${p.top - r.top}px)` }, { transform: 'none' }]
          : [{ opacity: 0, transform: 'scale(.9)' }, { opacity: 1, transform: 'none' }],
          { duration: 520, easing: 'cubic-bezier(.2,.7,.2,1)' });
      });
    });

    /* cursor bubble */
    const cur = $('#cursor'); if (!fine) return;
    let tx = 0, ty = 0, x = 0, y = 0, on = false;
    const loop = () => { x += (tx - x) * .2; y += (ty - y) * .2; cur.style.transform = `translate(${x}px,${y}px)`; if (on || Math.abs(tx - x) > .5) requestAnimationFrame(loop); };
    grid.addEventListener('pointermove', e => { tx = e.clientX; ty = e.clientY; if (!on) { on = true; x = tx; y = ty; cur.classList.add('on'); requestAnimationFrame(loop); } });
    grid.addEventListener('pointerleave', () => { on = false; cur.classList.remove('on'); });
  })();

  /* ---------- FAQ ---------- */
  $$('.q').forEach(q => {
    const b = $('button', q);
    b.addEventListener('click', () => {
      const o = !q.classList.contains('open');
      $$('.q.open').forEach(x => { if (x !== q) { x.classList.remove('open'); $('button', x).setAttribute('aria-expanded', 'false'); } });
      q.classList.toggle('open', o); b.setAttribute('aria-expanded', o);
    });
  });

  /* ---------- contact form → mailto (no backend needed) ---------- */
  const form = $('#form'), note = $('#formNote');
  form.addEventListener('submit', e => {
    e.preventDefault();
    const f = form.elements; let ok = true;
    ['name', 'email', 'msg'].forEach(k => {
      const bad = !f[k].value.trim() || (k === 'email' && !/^\S+@\S+\.\S+$/.test(f[k].value));
      f[k].classList.toggle('invalid', bad); if (bad) ok = false;
    });
    if (!ok) { note.textContent = 'Please fill in your name, a valid email and project details.'; return; }
    const body = `Name: ${f.name.value}\nEmail: ${f.email.value}\nService: ${f.service.value}\nBudget: ${f.budget.value}\n\n${f.msg.value}`;
    location.href = `mailto:hello@smtech24.com?subject=${encodeURIComponent('New project enquiry — ' + f.service.value)}&body=${encodeURIComponent(body)}`;
    note.textContent = 'Thanks! Your email app should open with the details filled in.';
  });
  $$('input,textarea', form).forEach(i => i.addEventListener('input', () => i.classList.remove('invalid')));
})();
